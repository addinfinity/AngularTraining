import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';


import {CourseComponent} from './course.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';


@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent,CourseComponent,ShoppingCartComponent,ProductComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
