import  {Component,Input} from '@angular/core';


@Component({
    selector:'course',
    template:`<h1> {{coursedetails.title}}  </h1>
    costs <h2> Price : {{coursedetails.price}} </h2>`
})
export class CourseComponent {
    @Input('details')    coursedetails:any = {};
}